# -*- coding: utf-8 -*-

from collections import namedtuple

Task = namedtuple("Task", ["key", "size", "other"])
